package com._d.pruebaunitaria.pruebasunitarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebasunitariasApplicationTests {

	@Test
	void contextLoads() {
	}

}
