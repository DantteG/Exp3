package com._d.pruebaunitaria.pruebasunitarias.calculadora;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CalculadoraTest{

    @Test
    @DisplayName ("prueba de suma")
    public void sumarTest(){
        Calculadora calc =new Calculadora();
        assertEquals(5, calc.sumar(2, 3));

        assertNotEquals(8, calc.sumar(2, 3));
    }

    @Test
    @DisplayName ("pruabe de division")
    @Disabled ("desabiitado por ahora")
    public void dividirTest(){
        Calculadora calc = new Calculadora();
        assertTrue(calc.dividir(6, 3) == 2);

        assertFalse(calc.dividir(6, 3) == 6);
    }
}
