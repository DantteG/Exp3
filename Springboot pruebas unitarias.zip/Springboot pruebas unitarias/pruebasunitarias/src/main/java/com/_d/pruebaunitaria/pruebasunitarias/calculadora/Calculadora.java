package com._d.pruebaunitaria.pruebasunitarias.calculadora;

public class Calculadora {


    int sumar (int a, int b){
        return a + b;
    }
    int dividir(int a, int b){
        return a/b;
        }
    int multiplicacion (int a, int b){
            return a*b;
        }
    int restar (int a, int b){
        return a-b;
    }
}
