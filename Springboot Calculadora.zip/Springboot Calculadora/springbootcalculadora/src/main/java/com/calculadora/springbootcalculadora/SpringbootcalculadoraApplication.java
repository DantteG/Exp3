package com.calculadora.springbootcalculadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootcalculadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcalculadoraApplication.class, args);
	}

}
