package com.calculadora.springbootcalculadora.restcontrollers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.calculadora.springbootcalculadora.services.CalculadoraService;

@RestController
@RequestMapping("/calculadora")
public class CalculadoraRestController {

    private final CalculadoraService calculadoraservice;

    public CalculadoraRestController(CalculadoraService calculadoraService){
        this.calculadoraservice = calculadoraService;
    }

    @GetMapping("/sumar")
    public int sumar(@RequestParam int a, @RequestParam int b) {
        return calculadoraservice.sumar(a, b);
    }
    
    @GetMapping("/multiplicar")
    public int multiplicar(@RequestParam int a, @RequestParam int b) {
        return calculadoraservice.multiplicar(a, b);
    }
    
    @GetMapping("/restar")
    public int restar(@RequestParam int a, @RequestParam int b) {
        return calculadoraservice.restar(a, b);
    }
    
    @GetMapping("/dividir")
    public int dividir(@RequestParam int a, @RequestParam int b) {
        return calculadoraservice.dividir(a, b);
    }
    


}
