package com.calculadora.springbootcalculadora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcalculadoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
