package com.duoc.springboot.fullrest.fullrest.repositories;

import org.springframework.data.repository.CrudRepository;

import com.duoc.springboot.fullrest.fullrest.entities.Producto;

public interface ProductoRepositories extends CrudRepository<Producto, Long> {

}
