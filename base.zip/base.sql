SELECT * FROM base.producto;
use base;
insert into producto (nombre, descripcion, precio) values ('sopaipillas', 'producto chileno', 300);
insert into producto (nombre, descripcion, precio) values ('super ocho', 'producto chileno', 450);
insert into producto (nombre, descripcion, precio) values ('monster', 'producto daña la salud', 1800);
insert into producto (nombre, descripcion, precio) values ('completo', 'producto chileno', 2500);
select * from producto;